conda create -n semantic_baselines python=3.8
conda activate semantic_baselines
pip install -r ./setup/requirements.txt
